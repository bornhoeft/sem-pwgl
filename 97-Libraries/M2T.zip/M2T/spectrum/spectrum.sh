#!/bin/bash
/Applications/Praat.app/Contents/MacOS/Praat --run ~/PWGL-User/User-library/M2T/spectrum/spectrum.praat $1
